#include "syssafemanage.h"
#include <QDebug>
#include "ui_syssafemanage.h"
#include "help.h"
#include "manager.h"
#include "adminman.h"

SysSafeManage::SysSafeManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SysSafeManage),pback(new sqlback)
{
    ui->setupUi(this);
sqlback * pback=new sqlback;

}
SysSafeManage::~SysSafeManage()
{
    delete ui;
}




void SysSafeManage::on_pushButton_2_clicked()
{
//备份，转储db到d盘变成.sql文件
pback->backup();
}

void SysSafeManage::on_pushButton_3_clicked()
{  help *hp=new help;
 hp->show();
}

void SysSafeManage::on_pushButton_huifu_released()
{//执行d盘变成.sql文件，即恢复
    pback->reset();
}

//管理密码
void SysSafeManage::on_pushButton_released()
{
    manager *ma = new manager;
    this->hide();
    ma->show();



}

//管理员账号管理
void SysSafeManage::on_pushButton_4_released()
{

    AdminMan *ma = new  AdminMan;
     this->hide();
     ma->show();
}


