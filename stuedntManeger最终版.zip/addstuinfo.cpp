#include "addstuinfo.h"
#include "ui_addstuinfo.h"
#include "global.h"
#include "stuinfomanage.h"
#include <QMessageBox>
#include <iostream>
#include <QDebug>
#include <QCryptographicHash>
addStuInfo::addStuInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addStuInfo)
{
    ui->setupUi(this);
    ui->sexBox->addItem("男");
    ui->sexBox->addItem("女");
}

addStuInfo::~addStuInfo()
{
    delete ui;
}

void addStuInfo::on_pushButton_3_clicked()
{
    this->hide();
    stuinfomanage *sif = new stuinfomanage;
    sif->show();
}

void addStuInfo::on_clear_button_clicked()
{
    ui->sno_lineEdit->clear();
    ui->sname_lineEdit->clear();
    ui->sexBox->setCurrentIndex(0);
    ui->sbirth_lineEdit->clear();
    ui->clano_lineEdit->clear();
    ui->sorigin_lineEdit->clear();
    ui->sstatus_lineEdit->clear();
    ui->s_year_lineEdit->clear();
    ui->shome_lineEdit->clear();
    ui->szipcode_lineEdit->clear();
    ui->snote_lineEdit->clear();
}

void addStuInfo::on_submit_button_clicked()
{
    QString sno = ui->sno_lineEdit->text();
    QString sname = ui->sname_lineEdit->text();
    QString sex = ui->sexBox->currentText();
    QString sbirth = ui->sbirth_lineEdit->text();
    QString s_year=ui->s_year_lineEdit->text();
    QString clano=ui->clano_lineEdit->text();
    QString sorigin=ui->sorigin_lineEdit->text();
    QString sstatus=ui->sstatus_lineEdit->text();
    QString shome=ui->shome_lineEdit->text();
    QString szipcode=ui->szipcode_lineEdit->text();
    QString snote=ui->snote_lineEdit->text();
   QString   sid=ui->sid_lineEdit           ->text();

    if(sno.isEmpty() || sname.isEmpty())
    {
        QMessageBox::warning(this, "警告", "输入信息不能留空！");
        return;
    }


    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select sno from student where sno = '" + sno + "'");

    if(query.next())
    {
        QMessageBox::warning(this, "新增出错", "该学号已经存在！");
        return;
    }

    query.exec("select clano from class where clano = '" + clano + "'");
    if(query.size() == 0)
    {
        QMessageBox::warning(this, "新增出错", "该班级号不存在！");
        return;
    }

 //开始插入学生信息的事务
     query.exec("begin");

 //插入stuent表
    QString originPwd = "123456";
   QString md5_pwd = QCryptographicHash::hash(originPwd.toLatin1(),QCryptographicHash::Md5).toHex();
    QString insert_qs=QString("insert into student values('%0','%1','%2','%3','%4','%5','%6','%7','%8','%9','%10','%11','%12')")
            .arg(sno).arg(clano).arg(sname).arg(sex).arg(sbirth).arg(sorigin).arg(sstatus)
            .arg(s_year).arg(shome).arg(szipcode).arg(snote).arg(md5_pwd).arg("正常");
    query.exec(insert_qs);

//插入stu_sid表
    QString insert_qs2=QString("insert into stu_sid values('%0','%1')").arg(sno).arg(sid);
    query.exec(insert_qs2);
//结束事务
    query.exec("commit");

//查看是否插入
    QString work=QString("select sno from student where sno='%0' ").arg(sno);
    bool iswork=query.exec(work);
    if(iswork)
        QMessageBox::information(this, "提示", "新增学生成功！");
    else {
        QMessageBox::warning(this, "新增失败", insert_qs);
    }

}
