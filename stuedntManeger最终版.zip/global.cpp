#include "global.h"
#include <QSqlError>
QString sqlUser = "root";
QString sqlPort = "3306";
QString sqlDatabase = "student_manager";
QString sqlPwd = "123456";
QString sqlLocalHost = "localhost";
QString username_Current = "";
QString pwd_Current = "";
QString sName_Current = "";
QVariantList list_all_student;

void connect_to_database(QSqlDatabase db)
{
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        db = QSqlDatabase::database("qt_sql_default_connection");
    else
        db = QSqlDatabase::addDatabase("QMYSQL");

    db.setHostName(sqlLocalHost);
    db.setUserName(sqlUser);
    db.setPassword(sqlPwd);
    db.setDatabaseName(sqlDatabase);

    if(!db.open())
     {   qDebug() << "connect fail";
             qDebug() << db.lastError().text(); }
    else
    {
        qDebug() << "success";
    }
}


