#include "allcourseinfo.h"
#include "ui_allcourseinfo.h"
#include "global.h"
#include "coursemanage.h"
#include "exporttable.h"
#include <QMessageBox>
#include <QInputDialog>

allCourseInfo::allCourseInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::allCourseInfo)
{
    ui->setupUi(this);

}

allCourseInfo::~allCourseInfo()
{
    delete ui;
}


//更新
void allCourseInfo::UPDATE_ALL()
{
    ui->courseIInfoTable->clearContents();
    ui->courseIInfoTable->setRowCount(0);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);
    QString dno = ui->dno_lineEdit->text();

    QString sel1="select dno,dname,cno,cname,cteacher,cterm,ccredit,cnote from dept_course_view ";
    query.exec(sel1);
    qDebug()<<sel1;

    while(query.next())
    {
        QString dno= query.value(0).toString();
        QString dname = query.value(1).toString();
        QString cno = query.value(2).toString();
        QString cname =query.value(3).toString();
        QString cteacher =query.value(4).toString();
        QString cterm =query.value(5).toString();
        QString ccredit =query.value(6).toString();
        QString cnote =query.value(7).toString();

        //QStringList是从QList<String>继承而来，并添加了一些好用的方法，如join()、filter、split()。
        QStringList q;
        q << dno << dname << cno << cname << cteacher << cterm << ccredit << cnote;

        int rowCount = ui->courseIInfoTable->rowCount();
        ui->courseIInfoTable->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            //获得现在query指向的记录在结果集中的编号。
            item->setText(q.at(i));
            ui->courseIInfoTable->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->courseIInfoTable->columnCount();
    int rowCount = ui->courseIInfoTable->rowCount();

    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->courseIInfoTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }





}
//返回
void allCourseInfo::on_back_button_clicked()
{
    this->hide();
    courseManage *cm = new courseManage;
    cm->show();
}

//导出
void allCourseInfo::on_export_button_clicked()
{
    Table2Excel(ui->courseIInfoTable, "专业课程信息");
}



//查询
void allCourseInfo::on_select_button_clicked()
{
    //防止重复出现
    ui->courseIInfoTable->clearContents();
    ui->courseIInfoTable->setRowCount(0);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);
    QString dno = ui->dno_lineEdit->text();

    //通过学号在视图中检索信息
    QString sel1="select dno,dname,cno,cname,cteacher,cterm,ccredit,cnote from dept_course_view where dno= '"+ dno +"'";
    query.exec(sel1);
    qDebug()<<sel1<<endl;


    while(query.next())
    {
        QString dno= query.value(0).toString();
        QString dname = query.value(1).toString();
        QString cno = query.value(2).toString();
        QString cname =query.value(3).toString();
        QString cteacher =query.value(4).toString();
        QString cterm =query.value(5).toString();
        QString ccredit =query.value(6).toString();
        QString cnote =query.value(7).toString();
        //QStringList是从QList<String>继承而来，并添加了一些好用的方法，如join()、filter、split()。
        QStringList q;
        q << dno << dname << cno << cname << cteacher << cterm << ccredit << cnote ;

        int rowCount = ui->courseIInfoTable->rowCount();
        ui->courseIInfoTable->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            //获得现在query指向的记录在结果集中的编号。
            item->setText(q.at(i));
            ui->courseIInfoTable->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->courseIInfoTable->columnCount();
    int rowCount = ui->courseIInfoTable->rowCount();

    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->courseIInfoTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }
}

void allCourseInfo::on_delete_button_clicked()
{
    QString dno = ui->dno_lineEdit->text();
    QString cno = ui->cno_lineEdit->text();
    if(dno.isEmpty() || cno.isEmpty())
    {
        QMessageBox::warning(this, "删除失败", "信息不能为空！");
        return;
    }
    QString sql=QString("DELETE FROM dept_course WHERE dno='%0'and cno='%1'").arg(dno).arg(cno);
    qDebug()<<sql<<endl;

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

     bool isDeleteSuccess = query.exec(sql);
    if(isDeleteSuccess)
    {
        QMessageBox::information(this, "提示", "删除成功");

        ui->cno_lineEdit->clear();
        ui->dno_lineEdit->clear();
        UPDATE_ALL();
    }
    else
    {
        QMessageBox::warning(this, "删除失败", "请检查输入信息！");

        ui->cno_lineEdit->clear();
        ui->dno_lineEdit->clear();
    }

}

void allCourseInfo::on_add_buttom_clicked()
{
    QString dno = ui->dno_lineEdit->text();
    QString cno = ui->cno_lineEdit->text();
    QString message=QString("是否要把%0课程添加到%1专业下？").arg(cno).arg(dno);
    if (QMessageBox::question(NULL,"添加信息",message,QMessageBox::Yes|QMessageBox::No)==QMessageBox::Yes)
    {
        QString sql=QString("insert into dept_course(dno,cno) VALUES('%0','%1')").arg(dno).arg(cno);
        qDebug()<<sql<<endl;

        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        bool isSuccess = query.exec(sql);
        if(isSuccess)
        {
            QMessageBox::information(this, "提示", "添加成功");

            ui->cno_lineEdit->clear();
            ui->dno_lineEdit->clear();
        }
        else {
            QMessageBox::warning(this, "提示", "添加失败！");

            ui->cno_lineEdit->clear();
            ui->dno_lineEdit->clear();
        }
      }
      UPDATE_ALL();
}


void allCourseInfo::on_list_button_clicked()
{
    UPDATE_ALL();
}

void allCourseInfo::on_courseIInfoTable_cellClicked(int row, int column)
{
    column = 0;
    QString dno = ui->courseIInfoTable->item(row, 0)->text();
    QString cno = ui->courseIInfoTable->item(row, 2)->text();
    ui->cno_lineEdit->setText(cno);
    ui->dno_lineEdit->setText(dno);

}

void allCourseInfo::on_tongji_buttom_clicked()
{
    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);
    QString dno = ui->dno_lineEdit->text();

    //统计专业下课程数目
    QString tongji ="select count(*) from dept_course where dno=  '"+dno+"'";
    qDebug()<<tongji<<endl;
    query.exec(tongji);
    if(query.next())
    {
       QString sum = query.value(0).toString();
       //显示sum
       ui->sum_lineEdit->setText(sum);
    }

}
