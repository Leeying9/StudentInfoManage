#include "gradestaticsbystu.h"
#include "ui_gradestaticsbystu.h"
#include "grademanage.h"
#include "global.h"
#include <QMessageBox>

gradeStaticsByStu::gradeStaticsByStu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gradeStaticsByStu)
{
    ui->setupUi(this);
}

gradeStaticsByStu::~gradeStaticsByStu()
{
    delete ui;
}

void gradeStaticsByStu::on_back_button_clicked()
{
    this->hide();
    gradeManage *gm = new gradeManage;
    gm->show();
}

void gradeStaticsByStu::on_start_button_clicked()
{
    QString sno = ui->sId_lineEdit->text();

    if(sno.isEmpty())
    {
        QMessageBox::warning(this, "统计出错", "学号信息不能为空");
        ui->creditSum_lineEdit->clear();
        ui->avgGrade_lineEdit->clear();
        ui->maxGrade_lineEdit->clear();
        ui->minGrade_lineEdit->clear();
        ui->notpassSum_lineEdit->clear();
        ui->selectedSum_lineEdit->clear();
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec("select sno from student where sno = '" + sno + "'");

    if(!query.next())
    {
        QMessageBox::warning(this, "统计出错", "该学生不存在！");
        ui->creditSum_lineEdit->clear();
        ui->avgGrade_lineEdit->clear();
        ui->maxGrade_lineEdit->clear();
        ui->minGrade_lineEdit->clear();
        ui->notpassSum_lineEdit->clear();
        ui->selectedSum_lineEdit->clear();
        return;
    }

    query.exec("select sno from sc where sno = '" + sno + "'");
    if(!query.next())
    {
        QMessageBox::warning(this, "统计出错", "该学生没有选课信息！");
        ui->creditSum_lineEdit->clear();
        ui->avgGrade_lineEdit->clear();
        ui->maxGrade_lineEdit->clear();
        ui->minGrade_lineEdit->clear();
        ui->notpassSum_lineEdit->clear();
        ui->selectedSum_lineEdit->clear();
        return;
    }

    query.exec("select count(cno) from sc where sno = '" + sno + "'");

    if(query.next())
    {
        QString courseSum = query.value(0).toString();
        ui->selectedSum_lineEdit->setText(courseSum);
    }

    query.exec("select count(*) from sc where scgrade < 60 and sno = '" + sno + "'");
    if(query.next())
    {
        QString notPassSum = query.value(0).toString();
        ui->notpassSum_lineEdit->setText(notPassSum);
    }

    query.exec("select max(scgrade) from sc where sno = '" + sno + "'");
    if(query.next())
    {
        QString maxScore = query.value(0).toString();
        ui->maxGrade_lineEdit->setText(maxScore);
    }

    query.exec("select min(scgrade) from sc where sno = '" + sno + "'");
    if(query.next())
    {
        QString minScore = query.value(0).toString();
        ui->minGrade_lineEdit->setText(minScore);
    }

    query.exec("select avg(scgrade) from sc where sno = '" + sno + "'");
    if(query.next())
    {
        QString avgScore = query.value(0).toString();
        ui->avgGrade_lineEdit->setText(avgScore);
    }

    query.exec("select sum(ccredit) from course where cno in (select cno from sc where sno = '" + sno + "' and scgrade > 60)");
    if(query.next())
    {
        QString creditSum = query.value(0).toString();
        ui->creditSum_lineEdit->setText(creditSum);
    }
}
