#include "college_man.h"
#include "ui_college_man.h"
#include "classinfomanage.h"
#include "manager.h"
#include "global.h"
#include <QMessageBox>
#include <QInputDialog>
#include "exporttable.h"

college_man::college_man(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::college_man)
{
    ui->setupUi(this);

}

college_man::~college_man()
{
    delete ui;
}

void college_man::updataTable()
{

        ui->co_dept_table->clearContents();
        ui->co_dept_table->setRowCount(0);

        QSqlDatabase db;
        connect_to_database(db);

        QSqlQuery query(db);

        query.exec("select cono,coname,dno,dname,clano,claname,`master`,coadd,dadd FROM co_dept_class_view order by cono");

        while(query.next())
        {
            QString cono = query.value(0).toString();
            QString coname = query.value(1).toString();
            QString dno = query.value(2).toString();
            QString dname = query.value(3).toString();
            QString clano = query.value(4).toString();
             QString claname = query.value(5).toString();
              QString master = query.value(6).toString();
                QString coadd = query.value(7).toString();
                 QString dadd = query.value(8).toString();
            QStringList q;
            q << cono << coname <<dno<<dname <<clano<<claname<<master<<coadd<<dadd;

            int rowCount = ui->co_dept_table->rowCount();
            ui->co_dept_table->insertRow(rowCount);

            for(int i = 0; i<q.size(); i++)
            {
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(q.at(i));
                ui->co_dept_table->setItem(rowCount, i, item);
            }
        }

        int columnCount = ui->co_dept_table->columnCount();
        int rowCount = ui->co_dept_table->rowCount();


    //每行每列都对齐
        for(int i = 0; i <columnCount; i++)
        {
            for(int j = 0; j < rowCount; j++)
            {
                ui->co_dept_table->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
            }
        }
    //

}

void college_man::updataTable2()
{
    ui->table2->clearContents();
    ui->table2->setRowCount(0);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select dno,dname,clano,claname,`master`,dadd FROM co_dept_class_view order by dno");

    while(query.next())
    {
        QString dno = query.value(0).toString();
        QString dname = query.value(1).toString();
        QString clano = query.value(2).toString();
        QString claname = query.value(3).toString();

         QString master = query.value(4).toString();
          QString dadd = query.value(5).toString();

        QStringList q;
        q  <<dno<<dname <<clano<<claname<<master<<dadd;

        int rowCount = ui->table2->rowCount();
        ui->table2->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(q.at(i));
            ui->table2->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->table2->columnCount();
    int rowCount = ui->table2->rowCount();


//每行每列都对齐
    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->table2->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }
    //
}

//基础函数更新表3
void college_man::updataTable3()
{
    ui->table3->clearContents();
    ui->table3->setRowCount(0);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select cono,coname,dno,dname,clano,claname,`master`,coadd,dadd FROM co_dept_class_view order by cono");

    while(query.next())
    {
        QString cono = query.value(0).toString();
        QString coname = query.value(1).toString();
        QString dno = query.value(2).toString();
        QString dname = query.value(3).toString();
        QString clano = query.value(4).toString();
         QString claname = query.value(5).toString();
          QString master = query.value(6).toString();
            QString coadd = query.value(7).toString();
             QString dadd = query.value(8).toString();
        QStringList q;
        q  <<cono<<coname<<dno<<dname <<coadd<<dadd;

        int rowCount = ui->table3->rowCount();
        ui->table3->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(q.at(i));
            ui->table3->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->table3->columnCount();
    int rowCount = ui->table3->rowCount();


//每行每列都对齐
    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->table3->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }
    //
}


void college_man::on_cla_man_button_released()
{
    this->hide();
        classInfoManage *cim = new classInfoManage;
        cim->show();
}


 //鼠标点哪行哪列，自动填写,table1.
void college_man::on_co_dept_table_cellClicked(int row, int column)
{
        ui->currentSelected_label->setVisible(true);

        column = 0;
        QString cono = ui->co_dept_table->item(row, 0)->text();
        QString dno = ui->co_dept_table->item(row, 2)->text();
        QString clano = ui->co_dept_table->item(row, 4)->text();
        ui->cono_lineEdit->setText(cono);
        ui->dno_lineEdit->setText(dno);
        ui->clano_lineEdit->setText(clano);

}


//更新所有，table1
void college_man::on_addGrade_button_4_released()
{
    updataTable();
    ui->currentSelected_label->setVisible(false);

}

//查找按钮，table1
void college_man::on_find_button_released()
{
    int cntt=0;
   QString cono = ui->cono_lineEdit->text();
    QString clano = ui->clano_lineEdit->text();
    QString dno = ui->dno_lineEdit->text();

if(dno.isEmpty()&&clano.isEmpty()&&cono.isEmpty())return ;

    QString sql="select cono,coname,dno,dname,clano,claname,`master`,coadd,dadd FROM co_dept_class_view  where " ;
      if(!cono.isEmpty()){sql+=" cono='"+cono+"'";cntt++;}

      if(!dno.isEmpty()){
          if(cntt>=1)sql+="and ";
          sql+=" clano='"+clano+"'";
          cntt++;

      }
    if(!clano.isEmpty()){
        if(cntt>=2)sql+="and ";sql+=" clano='"+clano+"'";
    }


    sql+="order by cono";
    qDebug()<<sql<<endl;

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec(sql);
//clear table
    ui->co_dept_table->clearContents();
    ui->co_dept_table->setRowCount(0);
    //make table
    while(query.next())
    {
        QString cono = query.value(0).toString();
        QString coname = query.value(1).toString();
        QString dno = query.value(2).toString();
        QString dname = query.value(3).toString();
        QString clano = query.value(4).toString();
         QString claname = query.value(5).toString();
          QString master = query.value(6).toString();
            QString coadd = query.value(7).toString();
             QString dadd = query.value(8).toString();
        QStringList q;

  q << cono << coname <<dno<<dname <<clano<<claname<<master<<coadd<<dadd;
        int rowCount = ui->co_dept_table->rowCount();
        ui->co_dept_table->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(q.at(i));
            ui->co_dept_table->setItem(rowCount, i, item);
        }
    }
}
//第一页转到第二页
void college_man::on_dept_button_2_released()
{
    ui->stackedWidget->setCurrentIndex(1);
}

//第二页返回第一页
void college_man::on_back_stuButton_3_released()
{
     ui->stackedWidget->setCurrentIndex(0);
}

//第二页更新
void college_man::on_addGrade_button_6_released()
{   updataTable2();


}

void college_man::on_table2_cellClicked(int row, int column)
{



    column = 0;

    QString dno = ui->table2->item(row, 0)->text();
    QString clano = ui->table2->item(row, 2)->text();

    ui->dno2->setText(dno);
    ui->cla2->setText(clano);

}


//第二页查询
void college_man::on_find_button_3_released()
{   int cntt=0;
    QString clano = ui->cla2->text();
    QString dno = ui->dno2->text();

if(dno.isEmpty()&&clano.isEmpty())return ;

    QString sql="select dno,dname,clano,claname,`master`,dadd FROM co_dept_class_view where " ;

    if(!dno.isEmpty()){sql+=" dno='"+dno+"'";cntt++;}
    if(!clano.isEmpty()){
        if(cntt>=1)sql+="and ";
        sql+=" clano='"+clano+"'";

    }

    sql+="order by dno";
    qDebug()<<sql<<endl;

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec(sql);
//clear table
    ui->table2->clearContents();
    ui->table2->setRowCount(0);
    //make table
    while(query.next())
    {
        QString dno = query.value(0).toString();
        QString dname = query.value(1).toString();
        QString clano = query.value(2).toString();
        QString claname = query.value(3).toString();

         QString master = query.value(4).toString();
          QString dadd = query.value(5).toString();

        QStringList q;
        q  <<dno<<dname <<clano<<claname<<master<<dadd;


        int rowCount = ui->table2->rowCount();
        ui->table2->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(q.at(i));
            ui->table2->setItem(rowCount, i, item);
        }
    }

//    //查询完了后，文本框里显示表格第一条
//    int row=0;
//    QString dno_set = ui->co_dept_table->item(row, 0)->text();
//    QString clano_set = ui->co_dept_table->item(row, 2)->text();
//    ui->dno2->setText(dno_set);
//    ui->cla2->setText(clano_set);

}

void college_man::on_find_button_5_released()
{
    QString clano = ui->cla2->text();
    QString dno = ui->dno2->text();
    if(clano.isEmpty()||dno.isEmpty()){ QMessageBox::warning(this, "删除失败", "信息不能为空！");return;}
    QString sql=QString("DELETE FROM dept_class WHERE clano='%0'and dno='%1'").arg(clano).arg(dno);
    qDebug()<<sql<<endl;

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

     bool isDeleteSuccess = query.exec(sql);
    if(isDeleteSuccess)
    {
        QMessageBox::information(this, "提示", "删除成功");


        ui->dno2->clear();
        ui->cla2->clear();
        updataTable2();
    }
    else {
        QMessageBox::warning(this, "删除失败", "请检查输入信息！");

        ui->dno2->clear();
        ui->cla2->clear();
    }
}

void college_man::on_back_stuButton_released()
{   manager *m=new manager;
    this->hide();
    m->show();

}

void college_man::on_find_button_4_released()
{    QString clano = ui->cla2->text();
     QString dno = ui->dno2->text();
    //yes/no
    QString mes=QString("是否要把%0班级添加到%1专业下？").arg(clano).arg(dno);
    if (QMessageBox::question(NULL,"添加信息",mes,QMessageBox::Yes|QMessageBox::No)==QMessageBox::Yes)
    {
        QString sql=QString("insert into dept_class(dno,clano) VALUES('%0','%1')").arg(dno).arg(clano);
        qDebug()<<sql<<endl;

        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

         bool isSuccess = query.exec(sql);
        if(isSuccess)
        {
            QMessageBox::information(this, "提示", "添加成功");


            ui->dno2->clear();
            ui->cla2->clear();
            updataTable2();
        }
        else {
            QMessageBox::warning(this, "提示", "添加失败！");

            ui->dno2->clear();
            ui->cla2->clear();
        }



    }

}

//table3 返回0页面
void college_man::on_return3_Button_released()
{
    ui->stackedWidget->setCurrentIndex(0);
}

//table3 查看所有信息
void college_man::on_get3_Button_released()
{
    ui->dno3->clear();
    ui->cono3->clear();
    updataTable3();
}
//table3 查找
void college_man::on_find3_released()
{
    int cntt=0;
        QString cono = ui->cono3->text();
        QString dno = ui->dno3->text();

    if(dno.isEmpty()&&cono.isEmpty()){
        //clear一下
        ui->dno3->clear();
        ui->cono3->clear();
        return ;}
        QString sql="select cono,coname,dno,dname,clano,claname,`master`,coadd,dadd FROM co_dept_class_view  where " ;

        if(!dno.isEmpty()){sql+=" dno='"+dno+"'";cntt++;}
        if(!cono.isEmpty()){
            if(cntt>=1)sql+="and ";
            sql+=" cono='"+cono+"'";

        }

        sql+="order by cono";
        qDebug()<<sql<<endl;

        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        query.exec(sql);
    //clear table
        ui->table3->clearContents();
        ui->table3->setRowCount(0);
        //make table
        while(query.next())
        {
            QString cono = query.value(0).toString();
            QString coname = query.value(1).toString();
            QString dno = query.value(2).toString();
            QString dname = query.value(3).toString();
            QString clano = query.value(4).toString();
             QString claname = query.value(5).toString();
              QString master = query.value(6).toString();
                QString coadd = query.value(7).toString();
                 QString dadd = query.value(8).toString();
            QStringList q;

      q<<cono<<coname<<dno<<dname <<coadd<<dadd;
            int rowCount = ui->table3->rowCount();
            ui->table3->insertRow(rowCount);

            for(int i = 0; i<q.size(); i++)
            {
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(q.at(i));
                ui->table3->setItem(rowCount, i, item);
            }
        }

    //    //查询完了后，文本框里显示表格第一条
    //    int row=0;
    //    QString dno_set = ui->co_dept_table->item(row, 0)->text();
    //    QString clano_set = ui->co_dept_table->item(row, 2)->text();
    //    ui->dno2->setText(dno_set);
    //    ui->cla2->setText(clano_set);
}
//table3 删除
void college_man::on_delete3_released()
{
    QString cono = ui->cono3->text();
    QString dno = ui->dno3->text();
    if(dno.isEmpty()){ QMessageBox::warning(this, "删除失败", "信息不能为空！");return;}
    QString sql=QString("DELETE FROM co_d WHERE cono='%0'and dno='%1'").arg(cono).arg(dno);
    qDebug()<<sql<<endl;

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

     bool isDeleteSuccess = query.exec(sql);
    if(isDeleteSuccess)
    {
        QMessageBox::information(this, "提示", "删除成功");


        ui->dno2->clear();
        ui->cla2->clear();
        updataTable3();
    }
    else {
        QMessageBox::warning(this, "删除失败", "请检查输入信息！");

        ui->dno2->clear();
        ui->cla2->clear();
    }

}
//table3添加
void college_man::on_add3_released()
{
    QString cono = ui->cono3->text();
       QString dno = ui->dno3->text();
      //yes/no
      QString mes=QString("是否要把%0专业添加到%1院系下？").arg(dno).arg(cono);
      if (QMessageBox::question(NULL,"添加信息",mes,QMessageBox::Yes|QMessageBox::No)==QMessageBox::Yes)
      {
          QString sql=QString("insert into co_d(cono,dno) VALUES('%0','%1')").arg(cono).arg(dno);
          qDebug()<<sql<<endl;

          QSqlDatabase db;
          connect_to_database(db);
          QSqlQuery query(db);

           bool isSuccess = query.exec(sql);
          if(isSuccess)
          {
              QMessageBox::information(this, "提示", "添加成功");


              ui->dno3->clear();
              ui->cono3->clear();
              updataTable2();
          }
          else {
              QMessageBox::warning(this, "提示", "添加失败！");

              ui->dno3->clear();
              ui->cono3->clear();
          }



      }
      updataTable3();
}
//table3 鼠标点击表格
void college_man::on_table3_cellClicked(int row, int column)
{ ui->currentSelected_label->setVisible(true);

    column = 0;
    QString cono = ui->table3->item(row, 0)->text();
    QString dno = ui->table3->item(row, 2)->text();

    ui->cono3->setText(cono);
    ui->dno3->setText(dno);



}
//从表1跳转到 表3
void college_man::on_co_button_3_released()
{
    ui->stackedWidget->setCurrentIndex(2);
}





void college_man::on_dept_sum_button_clicked()
{
    QString dno = ui->dno_lineEdit->text();

    if(dno.isEmpty())
    {
        QMessageBox::warning(this, "输入出错", "专业号不能留空！");
        return;
    }
    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);
    QString sel2="select count(*) from co_dept_class_student_view where dno = '" + dno + "'";
    query.exec(sel2);
    qDebug()<<sel2;
    if(query.next())
    {
        QString dno_sum =query.value(0).toString();
        ui->dept_sum_lineEdit->setText(dno_sum);
    }

}

void college_man::on_co_sum_button_clicked()
{
    QString cono = ui->cono_lineEdit->text();

    if(cono.isEmpty())
    {
        QMessageBox::warning(this, "输入出错", "学院号不能留空！");
        return;
    }
    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);
    QString sel1="select count(*) from co_dept_class_student_view where cono = '" + cono + "'";
    query.exec(sel1);
    qDebug()<<sel1;
    if(query.next())
    {
        QString col_sum =query.value(0).toString();
        ui->cono_sum_lineEdit->setText(col_sum);
    }

}
