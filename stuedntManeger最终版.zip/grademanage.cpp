#include "grademanage.h"
#include "ui_grademanage.h"
#include "manager.h"
#include "global.h"
#include <QMessageBox>
#include "addnewgrade.h"
#include <QInputDialog>
#include "gradestaticsbystu.h"
#include "gradestaticsbycourse.h"
#include "exporttable.h"

gradeManage::gradeManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gradeManage)
{
    ui->setupUi(this);
    ui->gradeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->currentSelected_label->setVisible(false);
    ui->update_gradeButton->setDisabled(true);
    ui->delete_button->setDisabled(true);
    updataTable();
}
//查询student_sc_course_view，把结果显示在表格里
gradeManage::~gradeManage()
{
    delete ui;
}

void gradeManage::updataTable()
{
    ui->gradeTable->clearContents();
    ui->gradeTable->setRowCount(0);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select sno,cno,cname,scgrade,cteacher from student_sc_course_view order by sno");

    while(query.next())
    {
        QString sno = query.value(0).toString();
        QString cno = query.value(1).toString();
        QString cname = query.value(2).toString();
        QString scgrade = query.value(3).toString();
        QString cteacher = query.value(4).toString();
        QStringList q;
        q << sno << cno <<cname <<scgrade << cteacher;

        int rowCount = ui->gradeTable->rowCount();
        ui->gradeTable->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            item->setText(q.at(i));
            ui->gradeTable->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->gradeTable->columnCount();
    int rowCount = ui->gradeTable->rowCount();


//每行每列都对齐
    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->gradeTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }
//
}

void gradeManage::on_back_button_clicked()
{
    manager *m = new manager;
    this->hide();
    m->show();
}

void gradeManage::on_listAll_button_clicked()
{
    updataTable();
    ui->currentSelected_label->setVisible(false);
    ui->update_gradeButton->setDisabled(true);
    ui->delete_button->setDisabled(true);
//    ui->sno_lineEdit->clear();
//    ui->cno_lineEdit->clear();
}

void gradeManage::on_searchBysno_clicked()
{
    ui->gradeTable->clearContents();
    ui->gradeTable->setRowCount(0);

    ui->currentSelected_label->setVisible(false);
    ui->update_gradeButton->setDisabled(true);
    ui->delete_button->setDisabled(true);
//    ui->sno_lineEdit->clear();
//    ui->cno_lineEdit->clear();

    QString sno = ui->sno_lineEdit->text();
    //QString cno = ui->cno_lineEdit->text();

    if(sno.isEmpty())
    {
        QMessageBox::warning(this, "查询出错", "学号不能留空！");
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec("select sno from student where sno = '" + sno + "'");

    if(!query.next())
    {
        QMessageBox::warning(this, "查询出错", "该学号不存在！");
        return;
    }

    QString sel="select sno,cno,cname,scgrade,cteacher from student_sc_course_view WHERE sno='" + sno + "' order by cno";
    query.exec(sel);
    qDebug()<<sel;

    if(query.size() != 0)
    {

        while(query.next())
        {
            QString sno = query.value(0).toString();
            QString cno = query.value(1).toString();
            QString cname = query.value(2).toString();
            QString scgrade = query.value(3).toString();
            QString cteacher = query.value(4).toString();
            QStringList q;
            q << sno << cno <<cname <<scgrade << cteacher;

            int rowCount = ui->gradeTable->rowCount();
            ui->gradeTable->insertRow(rowCount);

            for(int i = 0; i<q.size(); i++)
            {
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(q.at(i));
                ui->gradeTable->setItem(rowCount, i, item);
            }
        }

        int columnCount = ui->gradeTable->columnCount();
        int rowCount = ui->gradeTable->rowCount();

        for(int i = 0; i <columnCount; i++)
        {
            for(int j = 0; j < rowCount; j++)
            {
                ui->gradeTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
            }
        }
    }
    else {
        QMessageBox::warning(this, "查询无果", "该学生没有成绩记录！");
    }

}

void gradeManage::on_searchBycno_clicked()
{
    ui->gradeTable->clearContents();
    ui->gradeTable->setRowCount(0);

    ui->currentSelected_label->setVisible(false);
    ui->update_gradeButton->setDisabled(true);
    ui->delete_button->setDisabled(true);
//    ui->sno_lineEdit->clear();
//    ui->cno_lineEdit->clear();

    //QString sno = ui->sno_lineEdit->text();
    QString cno = ui->cno_lineEdit->text();

    if(cno.isEmpty())
    {
        QMessageBox::warning(this, "查询出错", "课程号不能留空！");
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec("select cno from course where cno = '" + cno + "'");

    if(!query.next())
    {
        QMessageBox::warning(this, "查询出错", "该课程号不存在！");
        return;
    }

    QString sel1="select sno,cno,cname,scgrade,cteacher from student_sc_course_view WHERE cno= '" + cno + "' order by sno";
    query.exec(sel1);
    qDebug()<<sel1;

    if(query.size() != 0)
    {

        while(query.next())
        {
                QString sno = query.value(0).toString();
               QString cno = query.value(1).toString();
               QString cname = query.value(2).toString();
               QString scgrade = query.value(3).toString();
               QString cteacher = query.value(4).toString();
               QStringList q;
               q << sno << cno <<cname <<scgrade << cteacher;

            int rowCount = ui->gradeTable->rowCount();
            ui->gradeTable->insertRow(rowCount);

            for(int i = 0; i<q.size(); i++)
            {
                QTableWidgetItem *item = new QTableWidgetItem;
                item->setText(q.at(i));
                ui->gradeTable->setItem(rowCount, i, item);
            }
        }

        int columnCount = ui->gradeTable->columnCount();
        int rowCount = ui->gradeTable->rowCount();

        for(int i = 0; i <columnCount; i++)
        {
            for(int j = 0; j < rowCount; j++)
            {
                ui->gradeTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
            }
        }
    }
    else {
        QMessageBox::warning(this, "查询无果", "该课程没有成绩记录！");
    }
}

void gradeManage::on_addGrade_button_clicked()
{
    this->hide();
    addNewGrade *ang = new addNewGrade;
    ang->show();
}

//鼠标点哪行哪列，自动填写学号和课程号lineEdit
void gradeManage::on_gradeTable_cellClicked(int row, int column)
{
    column = 0;
    ui->currentSelected_label->setVisible(true);
    ui->update_gradeButton->setDisabled(false);
    ui->delete_button->setDisabled(false);

    QString sno = ui->gradeTable->item(row, 0)->text();
    QString cno = ui->gradeTable->item(row, 1)->text();

    ui->sno_lineEdit->setText(sno);
    ui->cno_lineEdit->setText(cno);
}

void gradeManage::on_update_gradeButton_clicked()
{
    bool isOk;
    QString scgrade = QInputDialog::getText(this, "成绩修改", "请输入要修改的成绩", QLineEdit::Normal, "输入成绩", &isOk);

    if(isOk)
    {
        QString sno = ui->sno_lineEdit->text();
        QString cno = ui->cno_lineEdit->text();

        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        bool isUpdateSuccess = query.exec(QString("UPDATE student_sc_course_view set scgrade='%0' WHERE sno='%1' and cno ='%2'").arg(scgrade).arg(sno).arg(cno));

        if(isUpdateSuccess)
        {
            QMessageBox::information(this, "提示", "成绩修改成功");
            ui->currentSelected_label->setVisible(false);
            ui->update_gradeButton->setDisabled(true);
            ui->delete_button->setDisabled(true);
            ui->sno_lineEdit->clear();
            ui->cno_lineEdit->clear();
            updataTable();
        }
        else {
            QMessageBox::warning(this, "修改失败", "请检查输入信息！");
            ui->currentSelected_label->setVisible(false);
            ui->update_gradeButton->setDisabled(true);
            ui->delete_button->setDisabled(true);
            ui->sno_lineEdit->clear();
            ui->cno_lineEdit->clear();
        }
    }
}

void gradeManage::on_delete_button_clicked()
{
    QMessageBox::StandardButton btn;
    btn = QMessageBox::question(this, "确定删除", "确定删除此课程成绩信息？", QMessageBox::Yes|QMessageBox::No);

    if(btn == QMessageBox::Yes)
    {
        QString sno = ui->sno_lineEdit->text();
        QString cno = ui->cno_lineEdit->text();

        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        bool isDeleteSuccess = query.exec(QString("delete from sc where sno = '%0' and cno = '%1'").arg(sno).arg(cno));

        if(isDeleteSuccess)
        {
            QMessageBox::information(this, "提示", "删除成功");
            ui->currentSelected_label->setVisible(false);
            ui->update_gradeButton->setDisabled(true);
            ui->delete_button->setDisabled(true);
            ui->sno_lineEdit->clear();
            ui->cno_lineEdit->clear();
            updataTable();
        }
        else {
            QMessageBox::warning(this, "删除失败", "请检查输入信息！");
            ui->currentSelected_label->setVisible(false);
            ui->update_gradeButton->setDisabled(true);
            ui->delete_button->setDisabled(true);
            ui->sno_lineEdit->clear();
            ui->cno_lineEdit->clear();
        }
    }
}

void gradeManage::on_student_statistics_clicked()
{
    gradeStaticsByStu * gsbs = new gradeStaticsByStu;
    this->hide();
    gsbs->show();
}

void gradeManage::on_course_statistics_clicked()
{
    gradeStaticsByCourse *gsbc = new gradeStaticsByCourse;
    this->hide();
    gsbc->show();
}

void gradeManage::on_export_button_clicked()
{
    Table2Excel(ui->gradeTable, "成绩信息");
}



