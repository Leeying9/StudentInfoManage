#include "addnewgrade.h"
#include "ui_addnewgrade.h"
#include "global.h"
#include "grademanage.h"
#include <QMessageBox>

addNewGrade::addNewGrade(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addNewGrade)
{
    ui->setupUi(this);
}

addNewGrade::~addNewGrade()
{
    delete ui;
}

void addNewGrade::on_back_button_clicked()
{
    gradeManage *gm = new gradeManage;
    this->hide();
    gm->show();
}


void addNewGrade::on_submit_button_clicked()
{
    QString sno = ui->sno_lineEdit->text();
    QString cno = ui->cno_lineEdit->text();
    QString cname = ui->cname_lineEdit->text();
    QString scgrade = ui->scgrade_lineEdit->text();


    if(sno.isEmpty() || cno.isEmpty()  || scgrade.isEmpty() )
    {
        QMessageBox::warning(this, "插入出错", "除课程名外信息不能留空！");
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select sno from student where sno = '" + sno + "'");

    if(!query.next())
    {
        QMessageBox::warning(this, "插入出错", "该学生不存在！");
        return;
    }
    query.exec("select cno from course where cno = '" + cno + "' and cname='"+ cname + "'");

    if(!query.next())
    {
        QMessageBox::warning(this, "插入出错", "该课程名和课程号不存在或不对应！");
        return;
    }

    query.exec("select sno,cno from sc where sno = '" + sno + "' and cno = '" + cno + "'");

    if(query.next())
    {
        QMessageBox::warning(this, "插入出错", "该成绩信息已存在！\n请勿重复添加！");
        return;
    }


    bool isInsertSuccess = query.exec(QString("insert into sc(sno,cno,scgrade) values('%0','%1','%2')").arg(sno).arg(cno).arg(scgrade));
    if(isInsertSuccess)
    {
        QMessageBox::information(this, "提示", "添加成功");
    }
    else {
        QMessageBox::warning(this, "插入出错", "请检查输入信息！");
    }
}
