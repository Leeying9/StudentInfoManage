#ifndef SYSSAFEMANAGE_H
#define SYSSAFEMANAGE_H

#include <QWidget>
#include "sqlback.h"
namespace Ui {
class SysSafeManage;
}

class SysSafeManage : public QWidget
{
    Q_OBJECT

public:
    explicit SysSafeManage(QWidget *parent = 0);
    ~SysSafeManage();


private slots:


    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_huifu_released();

    void on_pushButton_released();

    void on_pushButton_4_released();



private:
    Ui::SysSafeManage *ui;
    sqlback * pback;
};

#endif // SYSSAFEMANAGE_H
