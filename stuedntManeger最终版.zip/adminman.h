#ifndef ADMINMAN_H
#define ADMINMAN_H

#include <QWidget>

namespace Ui {
class AdminMan;
}

class AdminMan : public QWidget
{
    Q_OBJECT

public:
    explicit AdminMan(QWidget *parent = 0);
    ~AdminMan();

private slots:
    void on_submit_button_clicked();

    void on_back_button_clicked();

    void on_oldPwd_lineEdit_textChanged(const QString &arg1);

    void on_newPwd_lineEdit_textChanged(const QString &arg1);

    void on_repeatPwd_lineEdit_textChanged(const QString &arg1);

private:
    Ui::AdminMan *ui;
};

#endif // ADMINMAN_H
