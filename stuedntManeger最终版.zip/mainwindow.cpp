#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QTime>
#include <QMouseEvent>
#include <QtDebug>
#include <global.h>
#include <QCryptographicHash>
//#include <QCoreApplication>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->Login_password->setEchoMode(QLineEdit::Password);
    ui->Login_username->setPlaceholderText("请输入学号或管理员账号");
    ui->Login_password->setPlaceholderText("请输入密码");

    ui->adminButton->setChecked(true);
    loginFailTimes = 0;


//    //记得删除！！
//    this->hide();
//    m = new manager;
//    m->show();
//    //记得删除！！

}

MainWindow::~MainWindow()
{
    delete ui;
    //timer.stop();
}





void MainWindow::on_LoginButton_clicked()
{
    QString input_userName = ui->Login_username->text();

    QString input_password = QCryptographicHash::hash(ui->Login_password->text().toLatin1(), QCryptographicHash::Md5).toHex();



    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    if(ui->adminButton->isChecked())
    {

        query.exec("select adminName from admin where adminName = '" + input_userName + "'");

        if(!query.next())
        {
            QMessageBox::warning(this, "登录失败", "该用户不存在！");
            return;
        }

        query.exec("select aid, adminName, password from admin where adminName = '" + input_userName + "' and password = '" + input_password + "'");

        bool isLoginSuccess = false;

        if(query.next())
        {
            QString userName = query.value(1).toString();
            QString pwd = query.value(2).toString();
            username_Current = userName;
            pwd_Current = ui->Login_password->text();
            isLoginSuccess = true;

            this->hide();
            m = new manager;
            m->show();
        }

        if(!isLoginSuccess)
        {
            QMessageBox::warning(this, "登录失败", "密码错误！");
            ui->Login_username->setFocus();
        }
    }

    if(ui->studentButton->isChecked())
    {
        query.exec("select sno from student where sno = '" + input_userName + "'");

        if(!query.next())
        {
            QMessageBox::warning(this, "登录失败", "该用户不存在！");
            return;
        }

        query.exec("select suserstatus from student where sno = '" + input_userName + "'");
        if(query.next())
        {
            QString status = query.value(0).toString();
            if(status.compare("冻结") == 0)
            {
                QMessageBox::warning(this, "登录失败", "该用户已被冻结\n请联系管理员进行解冻！");
                return;
            }
        }

        bool isLoginSuccess = false;

        query.exec("select sno, sname, spassword from student where sno = '" + input_userName + "' and spassword = '" + input_password + "'");

        if(query.next())
        {
            QString sNo = query.value(0).toString();
            QString sName = query.value(1).toString();
            QString pwd = query.value(2).toString();
            qDebug() << sNo << sName << pwd;
            username_Current = sNo;
            pwd_Current = ui->Login_password->text();
            sName_Current = sName;
            isLoginSuccess = true;
            qDebug() << "学生" + sName + "登录成功";
            this->hide();
            f = new studentForm;
            f->show();
        }

        if(!isLoginSuccess)
        {
            QMessageBox::warning(this, "警告", "密码错误！");
            loginFailTimes++;
            ui->Login_username->setFocus();
            ui->loginFailTimes_Label->setVisible(true);
            ui->loginFailTimes_Label->setText(QString("登录失败次数：%0 次").arg(loginFailTimes));
        }
    }


    if(loginFailTimes >= 3 && ui->studentButton->isChecked())
    {
        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        QString username = ui->Login_username->text();

        query.exec("update student set suserstatus = '冻结' where sno = '" + username + "'");

     //   ui->LoginButton->setDisabled(true);
     //   ui->clearButton->setDisabled(true);
        bool isdongjie=query.exec("select sno from student where  suserstatus = '冻结' where sno = '" + username + "'");
       if(isdongjie) QMessageBox::warning(this, "登录失败", "登录失败次数过多\n您的账户已被冻结！\n请联系管理员进行解冻");
       // loginFailTimes=0;

    }

}

void MainWindow::on_clearButton_clicked()
{
    ui->Login_username->clear();
    ui->Login_password->clear();

}
