#include "adminman.h"
#include "ui_adminman.h"
#include "syssafemanage.h"
#include "global.h"
#include <QMessageBox>
#include "mainwindow.h"
#include <QCryptographicHash>

AdminMan::AdminMan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdminMan)
{
    ui->setupUi(this);
    QLabel *lab = ui->label_useradmin;
    lab->setStyleSheet("color:#ff0000");
    lab->setText("当前管理员：" + username_Current);
}

AdminMan::~AdminMan()
{
    delete ui;
}

void AdminMan::on_submit_button_clicked()
{  //username_Current;
    //query.exec("select aid, adminName, password from admin where adminName = '" + input_userName + "' and password = '" + input_password + "'");

    QMessageBox::StandardButton btn;
        btn = QMessageBox::question(this, "确认提交", "确定要修改当前管理员密码吗？", QMessageBox::Yes|QMessageBox::No);
        if(btn == QMessageBox::Yes)
        {
            QSqlDatabase db;
            connect_to_database(db);

            QSqlQuery query(db);

            QString adminName = username_Current;
            //QString newPwd = ui->newPwd_lineEdit->text();
            QString newPwd = QCryptographicHash::hash(ui->newPwd_lineEdit->text().toLatin1(), QCryptographicHash::Md5).toHex();

            bool isResetPwdSuccess = query.exec("update admin set password = '" + newPwd + "' where adminName = '" + adminName + "'");

            if(isResetPwdSuccess)
            {
                QMessageBox::information(this, "提示", "修改成功！请重新登录！", QMessageBox::Yes);
                this->hide();
                MainWindow *mw = new MainWindow;
                mw->show();
            }
            else {
                QMessageBox::warning(this, "修改失败", "请检查密码格式！");
            }
        }
}

void AdminMan::on_back_button_clicked()
{
    this->hide();
    SysSafeManage *mf = new SysSafeManage;
    mf->show();
}

void AdminMan::on_oldPwd_lineEdit_textChanged(const QString &arg1)
{
    QString oldPwd = arg1;

        if(oldPwd.compare(pwd_Current) != 0)
        {
            ui->error_label->setText("原密码输入错误！");
            ui->submit_button->setDisabled(true);
        }
        else {
            ui->error_label->clear();
        }
}

void AdminMan::on_newPwd_lineEdit_textChanged(const QString &arg1)
{
    QString newPwd = arg1;
        //qDebug() << arg1 << pwd_Current;
        if(newPwd.compare(pwd_Current) == 0)
        {
            ui->error_label->setText("不可与原密码一致！");
            ui->submit_button->setDisabled(true);
        }
        else {
            ui->error_label->clear();
        }
}

void AdminMan::on_repeatPwd_lineEdit_textChanged(const QString &arg1)
{
    QString repeatedPwd = arg1;
    QString newPwd = ui->newPwd_lineEdit->text();
    if(repeatedPwd.compare(newPwd) != 0)
    {
        ui->error_label->setText("两次密码输入不一致！");
        ui->submit_button->setDisabled(true);

    }
    else {
        ui->error_label->clear();
        ui->submit_button->setDisabled(false);
    }
}
