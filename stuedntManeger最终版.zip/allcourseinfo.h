#ifndef ALLCOURSEINFO_H
#define ALLCOURSEINFO_H

#include <QWidget>

namespace Ui {
class allCourseInfo;
}

class allCourseInfo : public QWidget
{
    Q_OBJECT

public:
    explicit allCourseInfo(QWidget *parent = nullptr);
    ~allCourseInfo();
 void UPDATE_ALL();
private slots:
    void on_back_button_clicked();

    void on_export_button_clicked();

    void on_list_button_clicked();

    void on_select_button_clicked();

    void on_delete_button_clicked();

    void on_add_buttom_clicked();

    void on_courseIInfoTable_cellClicked(int row, int column);

    void on_tongji_buttom_clicked();

private:
    Ui::allCourseInfo *ui;
};

#endif // ALLCOURSEINFO_H
