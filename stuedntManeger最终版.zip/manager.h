#ifndef MANAGER_H
#define MANAGER_H

#include <QWidget>

namespace Ui {
class manager;
}

class manager : public QWidget
{
    Q_OBJECT

public:
    explicit manager(QWidget *parent = nullptr);
    ~manager();
    void keyPressEvent(QKeyEvent *event)override;
private slots:
    void on_pushButton_9_clicked();

    void on_stu_inform_guanlipushButton_clicked();

    void on_class_managepushButton_clicked();

    void on_course_manageButton_clicked();

    void on_scoremanagepushButton_clicked();

    void on_college_manage_pushButton_released();

private:
    Ui::manager *ui;

};

#endif // MANAGER_H
