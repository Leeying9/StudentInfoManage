#ifndef COLLEGE_MAN_H
#define COLLEGE_MAN_H

#include <QWidget>

namespace Ui {
class college_man;
}

class college_man : public QWidget
{
    Q_OBJECT

public:
    explicit college_man(QWidget *parent = 0);
    ~college_man();
    void updataTable();
    void updataTable2();
    void updataTable3();

private slots:
    void on_cla_man_button_released();

    void on_co_dept_table_cellClicked(int row, int column);



    void on_addGrade_button_4_released();

    void on_find_button_released();

    void on_dept_button_2_released();

    void on_back_stuButton_3_released();

    void on_addGrade_button_6_released();

    void on_table2_cellClicked(int row, int column);

    void on_find_button_3_released();

    void on_find_button_5_released();

    void on_back_stuButton_released();

    void on_find_button_4_released();

    void on_return3_Button_released();

    void on_get3_Button_released();

    void on_find3_released();

    void on_delete3_released();

    void on_add3_released();

    void on_table3_cellClicked(int row, int column);

    void on_co_button_3_released();

//    void on_find_button_clicked();

    void on_dept_sum_button_clicked();

    void on_co_sum_button_clicked();

private:
    Ui::college_man *ui;
};

#endif // COLLEGE_MAN_H
