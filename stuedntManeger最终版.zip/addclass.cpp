#include "addclass.h"
#include "ui_addclass.h"
#include "global.h"
#include "classinfomanage.h"
#include <QMessageBox>

addClass::addClass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addClass)
{
    ui->setupUi(this);
}

addClass::~addClass()
{
    delete ui;
}

void addClass::on_back_button_clicked()
{
    classInfoManage *cim = new classInfoManage;
    this->hide();
    cim->show();
}

void addClass::on_submit_button_clicked()
{
    QString classId = ui->classId_lineEdit->text();
    QString className = ui->className_lineEdit->text();
    QString classMaster = ui->classMaster_lineEdit->text();

    if(classId.isEmpty() || className.isEmpty() || classMaster.isEmpty())
    {
        QMessageBox::warning(this, "输入出错", "班级信息不能留空！");
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);
    //QSqlQuery封装了在QSqlDatabase上执行的SQL查询中创建
    //QSqlQuery类通过 exec ()成员函数来执行DML (数据操作语言)语句

    //查询语句，实现查询班级号
    query.exec("select clano from class where class = '" + classId + "'");

    //next() ：query指向下一条记录，每执行一次该函数，便指向相邻的下一条记录
    if(query.next())
    {
        //QMessageBox::warning用来弹出提示框
        //第一个参数this，表示在当前程序顶层显示提示框，也可以为NULL，为NULL时，弹出的提示框有可能不在顶层
        //第二个参数是“Warning”，提示框标题，标题自己可以随意命名
        //第三个参数是提示框内容，自己可以随意命名
        QMessageBox::warning(this, "添加出错", "该班级号已存在！");
        return;
    }



    //arg( )里的参数在进行替换时，只会按照数字从小到大的顺序进行替换
    //只有比当前数字小的所有数字都替换完成了，才会替换当前数字，否则将当前数字和%按字符串处理。且数字为自然数！
    bool isInsertSuccess = query.exec(QString("insert into class values('%0','%1','%2')").arg(classId).arg(className).arg(classMaster));

    if(isInsertSuccess)
    {
        QMessageBox::information(this, "提示", "添加成功！");
    }
    else {
        QMessageBox::warning(this, "添加出错", "请检查输入信息！");
    }
}


