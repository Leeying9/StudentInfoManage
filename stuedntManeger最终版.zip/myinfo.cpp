#include "myinfo.h"
#include "ui_myinfo.h"
#include "global.h"
#include "studentform.h"
#include "resetpwd.h"

myInfo::myInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::myInfo)
{
    ui->setupUi(this);

    QString sId = username_Current;

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select sno,sname,ssex,claname,sorigin,sstatus from student_class_view where sno = '" + sId + "'");

    while(query.next())
    {
        ui->sNo_lineEdit->setText(query.value(0).toString());
        QString sname = query.value(1).toString();
        QString ssex = query.value(2).toString();
        QString claname = query.value(3).toString();
        QString sorigin = query.value(4).toString();
        QString sstatus = query.value(5).toString();


        ui->sname_lineEdit->setText(sname);
        ui->ssex_lineEdit->setText(ssex);
        ui->claname_lineEdit->setText(claname);
        ui->sorign_lineEdit->setText(sorigin);
        ui->sstatus_lineEdit->setText(sstatus);
    }
}

myInfo::~myInfo()
{
    delete ui;
}

void myInfo::on_back_button_clicked()
{
    this->hide();
    studentForm *sf = new studentForm;
    sf->show();
}

void myInfo::on_resetPwd_button_clicked()
{
    this->hide();
    resetPwd *rp = new resetPwd;
    rp->show();
}
