#include "gradestaticsbycourse.h"
#include "ui_gradestaticsbycourse.h"
#include "global.h"
#include "grademanage.h"
#include <QMessageBox>

gradeStaticsByCourse::gradeStaticsByCourse(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gradeStaticsByCourse)
{
    ui->setupUi(this);
}

gradeStaticsByCourse::~gradeStaticsByCourse()
{
    delete ui;
}

void gradeStaticsByCourse::on_back_button_clicked()
{
    gradeManage *gm = new gradeManage;
    this->hide();
    gm->show();
}

void gradeStaticsByCourse::on_search_button_clicked()
{
    QString cno = ui->cIano_lineEdit->text();
    if(cno.isEmpty())
    {
        QMessageBox::warning(this, "统计出错", "课程号不能留空！");
        ui->cName_lineEdit->clear();
        ui->teacher_lineEdit->clear();
        ui->maxScore_lineEdit->clear();
        ui->minScore_lineEdit->clear();
        ui->avgScore_lineEdit->clear();
        ui->selectSum_lineEdit->clear();
        ui->notPassSum_lineEdit->clear();
        return;
    }

    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);

    query.exec("select cno from course where cno = '" + cno + "'");
    if(!query.next())
    {
        QMessageBox::warning(this, "统计出错", "该课程不存在！");
        ui->cName_lineEdit->clear();
        ui->teacher_lineEdit->clear();
        ui->maxScore_lineEdit->clear();
        ui->minScore_lineEdit->clear();
        ui->avgScore_lineEdit->clear();
        ui->selectSum_lineEdit->clear();
        ui->notPassSum_lineEdit->clear();
        return;
    }

    query.exec("select cname,cteacher from course where cno = '" + cno + "'");
    if(query.next())
    {
        QString cname= query.value(0).toString();
        QString cteacher = query.value(1).toString();
        ui->cName_lineEdit->setText(cname);
        ui->teacher_lineEdit->setText(cteacher);
    }

    query.exec("select count(sno) from sc where cno = '" + cno + "'");
    if(query.next())
    {
        QString selectSum = query.value(0).toString();
        ui->selectSum_lineEdit->setText(selectSum);
    }

    query.exec("select max(scgrade), min(scgrade), avg(scgrade) from sc where cno = '" + cno + "'");

    if(query.next())
    {
        QString maxScore = query.value(0).toString();
        QString minScore = query.value(1).toString();
        QString avgScore = query.value(2).toString();
        ui->maxScore_lineEdit->setText(maxScore);
        ui->minScore_lineEdit->setText(minScore);
        ui->avgScore_lineEdit->setText(avgScore);
    }

    query.exec("select count(*) from sc where cno = '" + cno + "' and sc.scgrade < 60");

    if(query.next())
    {
        QString notPassSum = query.value(0).toString();
        ui->notPassSum_lineEdit->setText(notPassSum);
    }
}
