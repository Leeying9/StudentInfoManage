#include "myclass.h"
#include "ui_myclass.h"
#include <mainwindow.h>
#include "studentform.h"
#include "global.h"
#include <QSqlDatabase>
#include <iostream>

myclass::myclass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::myclass)
{
    ui->setupUi(this);

    QSqlDatabase db;
    connect_to_database(db);

    QString uid = username_Current;//学号
    QString myClass = "";
    QSqlQuery query(db);
//    qDebug() << uid;
    query.exec("select clano from student_class_view where sno = "+ uid);

    if(query.next())
    {
        myClass = query.value(0).toString();
    }


QString se="select sname, ssex, clano, claname, `master` from student_class_view where clano = '" + myClass+"'";
query.exec(se);

    if(query.next())
    {
        QString sname = query.value(0).toString();
        QString ssex = query.value(1).toString();
        QString cId = query.value(2).toString();
        QString cName = query.value(3).toString();
        QString cMaster = query.value(4).toString();

        ui->studentName_lineEdit->setText(sname);
        ui->studentSex_lineEdit->setText(ssex);
        ui->classId_lineEdit->setText(cId);
        ui->className_lineEdit->setText(cName);
        ui->classMaster_lineEdit->setText(cMaster);
    }

}

myclass::~myclass()
{
    delete ui;
}

void myclass::on_backButton_clicked()
{
    this->hide();
    studentForm * f2 = new studentForm;
    f2->show();
}
