#include "allclassinfo.h"
#include "ui_allclassinfo.h"
#include "global.h"
#include "classinfomanage.h"
#include "exporttable.h"

allClassInfo::allClassInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::allClassInfo)
{
    ui->setupUi(this);

    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select clano,claname,master from class");

    while(query.next())
    {
        //value(int n) ：获得属性的值。其中n表示你查询的第n个属性
        //比方上面我们使用“select * from student”就相当于“select id, name from student”
        //那么value(0)返回id属性的值，value(1)返回name属性的值。该函数返回QVariant类型的数据
        //关于该类型与其他类型的对应关系，可以在帮助中查看QVariant。
        QString classId = query.value(0).toString();
        QString className = query.value(1).toString();
        QString master =query.value(2).toString();

        //QStringList是从QList<String>继承而来，并添加了一些好用的方法，如join()、filter、split()。
        QStringList q;
        q << classId << className  << master;


        int rowCount = ui->classInfoTable->rowCount();
        ui->classInfoTable->insertRow(rowCount);

        for(int i = 0; i<q.size(); i++)
        {
            QTableWidgetItem *item = new QTableWidgetItem;
            //获得现在query指向的记录在结果集中的编号。
            item->setText(q.at(i));
            ui->classInfoTable->setItem(rowCount, i, item);
        }
    }

    int columnCount = ui->classInfoTable->columnCount();
    int rowCount = ui->classInfoTable->rowCount();

    for(int i = 0; i <columnCount; i++)
    {
        for(int j = 0; j < rowCount; j++)
        {
            ui->classInfoTable->item(j, i)->setTextAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
        }
    }
}

allClassInfo::~allClassInfo()
{
    delete ui;
}

void allClassInfo::on_back_button_clicked()
{
    this->hide();
    classInfoManage *cim = new classInfoManage;
    cim->show();
}

void allClassInfo::on_export_button_clicked()
{
    Table2Excel(ui->classInfoTable, "所有班级信息");
}
