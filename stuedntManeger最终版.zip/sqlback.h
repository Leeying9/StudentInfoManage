#ifndef SQLBACK_H
#define SQLBACK_H


class sqlback
{
public:
    sqlback();
    bool backup();
    bool reset();
};

#endif // SQLBACK_H
