#include "manager.h"
#include "ui_manager.h"
#include "global.h"
#include "mainwindow.h"
#include "stuinfomanage.h"
#include "classinfomanage.h"
#include "coursemanage.h"
#include "selectcoursemanage.h"
#include "grademanage.h"
#include "syssafemanage.h"
#include "college_man.h"
#include "QPushButton"
#include <QKeyEvent>
manager::manager(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::manager)
{
    ui->setupUi(this);
    QLabel *lab = ui->label_useradmin;
    lab->setStyleSheet("color:#ff0000");
    lab->setText("当前管理员：" + username_Current);

    //隐藏班级管理按钮，因为移动到院系班级信息管理那去了
    ui->class_managepushButton->hide();
}

manager::~manager()
{
    delete ui;
}

void manager::keyPressEvent(QKeyEvent *event)
{

if(event->key()==Qt::Key_Escape){

    this->hide();
    MainWindow *mw= new MainWindow;
    mw->show();
}


}

void manager::on_pushButton_9_clicked()
{
    this->hide();
    SysSafeManage *sp=new SysSafeManage;
    sp->show();
 }


void manager::on_stu_inform_guanlipushButton_clicked()
{
    this->hide();
    stuinfomanage *sif = new stuinfomanage;
    sif->show();
}

void manager::on_class_managepushButton_clicked()
{
    this->hide();
    classInfoManage *cim = new classInfoManage;
    cim->show();
}

void manager::on_course_manageButton_clicked()
{
    this->hide();
    courseManage *cm = new courseManage;
    cm->show();
}



void manager::on_scoremanagepushButton_clicked()
{
    gradeManage *gm = new gradeManage;
    this->hide();
    gm->show();
}

void manager::on_college_manage_pushButton_released()
{
    college_man *cm =new college_man;
    this->hide();
    cm->show();
}
