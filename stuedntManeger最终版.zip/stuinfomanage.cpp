#include "stuinfomanage.h"
#include "ui_stuinfomanage.h"
#include "global.h"
#include "manager.h"
#include <QMessageBox>
#include "addstuinfo.h"
#include "all_stu_info.h"
#include <QCryptographicHash>
#include <iostream>
#include <QDebug>

stuinfomanage::stuinfomanage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::stuinfomanage)
{
    ui->setupUi(this);
    ui->update_button->setDisabled(true);
    ui->delete_button->setDisabled(true);
    ui->reset_button->setDisabled(true);

    ui->sexBox->addItem("男");
    ui->sexBox->addItem("女");
    ui->statusBox->addItem("正常");
    ui->statusBox->addItem("冻结");

}

stuinfomanage::~stuinfomanage()
{
    delete ui;
}

void stuinfomanage::on_pushButton_7_clicked()
{
    manager *ma = new manager;
    this->hide();
    ma->show();
}

void stuinfomanage::on_pushButton_clicked()
{
    QString sno = ui->sno_lineEdit->text();

    if(sno.isEmpty())
    {
        ui->update_button->setDisabled(true);
        ui->delete_button->setDisabled(true);
        ui->reset_button->setDisabled(true);


        ui->sno_lineEdit          ->clear();
        ui->sname_lineEdit        ->clear();
        ui->sexBox                ->setCurrentIndex(0);
        ui->age_lineEdit          ->clear();
        ui->clano_lineEdit        ->clear();
        ui->sorigin_lineEdit      ->clear();
        ui->sstatus_lineEdit      ->clear();
        ui->sid_lineEdit          ->clear();
        ui->shome_lineEdit        ->clear();
        ui->szipcode              ->clear();
        ui->snote_lineEdit        ->clear();
        ui->statusBox             ->setCurrentIndex(0);
        ui->password_lineEdit     ->clear();

        QMessageBox::warning(this, "输入错误", "学号信息不能留空！");

        ui->sno_lineEdit->setFocus();
        return;
    }
    ui->update_button->setDisabled(false);
    ui->delete_button->setDisabled(false);
    ui->reset_button->setDisabled(false);
    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);
    //QString sql="select sno,sname,ssex,sbirth,clano,sorigin,sstatus,sid,shome,szipcode,snote,suserstatus,spassword from stu_stu_sid_view WHERE   stu_stu_sid_view.sno='2'";

    query.exec("select sno,sname,ssex,sbirth,clano,sorigin,sstatus,sid,shome,szipcode,snote,suserstatus,spassword from stu_stu_sid_view WHERE   stu_stu_sid_view.sno='" + sno + "'");

    if(query.next())
    {
        QString sno=query.value(0).toString();
        QString sname=query.value(1).toString();
        QString sex=query.value(2).toString();
        QString age=query.value(3).toString();

        QString clano=query.value(4).toString();
        QString sorigin=query.value(5).toString();
        QString sstatus=query.value(6).toString();
        QString sid=query.value(7).toString();

        QString shome=query.value(8).toString();
        QString szipcode=query.value(9).toString();


        QString snote=query.value(10).toString();
        QString status=query.value(11).toString();
        QString password=query.value(12).toString();


        ui->sname_lineEdit->setText(sname);
        ui->sexBox->setCurrentIndex(ui->sexBox->findText(sex));
        ui->age_lineEdit->setText(age);
        ui->clano_lineEdit->setText(clano);

        ui->sid_lineEdit->setText(sid);
        ui->sorigin_lineEdit->setText(sorigin);
        ui->shome_lineEdit->setText(shome);
        ui->szipcode->setText(szipcode);
        ui->statusBox->setCurrentIndex(ui->statusBox->findText(status));
        ui->sstatus_lineEdit->setText(sstatus);
        ui->snote_lineEdit->setText(snote);
        ui->password_lineEdit->setText("********");



    }
    else
    {
        ui->update_button->setDisabled(true);
        ui->delete_button->setDisabled(true);
       ui->reset_button->setDisabled(true);


       ui->sno_lineEdit          ->clear();
       ui->sname_lineEdit        ->clear();
       ui->sexBox                ->setCurrentIndex(0);
       ui->age_lineEdit          ->clear();
       ui->clano_lineEdit        ->clear();
       ui->sorigin_lineEdit      ->clear();
       ui->sstatus_lineEdit      ->clear();
       ui->sid_lineEdit          ->clear();
       ui->shome_lineEdit        ->clear();
       ui->szipcode              ->clear();
       ui->snote_lineEdit        ->clear();
       ui->statusBox             ->setCurrentIndex(0);
       ui->password_lineEdit     ->clear();
    QMessageBox::warning(this, "查询无果", "该学生不存在");

        ui->sno_lineEdit->setFocus();


    }
}

void stuinfomanage::on_update_button_clicked()
{
    QString   sno=ui->sno_lineEdit           ->text();
    QString   sname=ui->sname_lineEdit       ->text();
    QString  sex =ui->sexBox                 ->currentText();
    QString  age =ui->age_lineEdit           ->text();
    QString  clano =ui->clano_lineEdit       ->text();
    QString  sorigin =ui->sorigin_lineEdit   ->text();
    QString  sstatus =ui->sstatus_lineEdit   ->text();
    QString   sid=ui->sid_lineEdit           ->text();
    QString shome =ui->shome_lineEdit        ->text();
    QString  szipcode =ui->szipcode          ->text();
    QString   snote=ui->snote_lineEdit       ->text();
    QString   status=ui->statusBox           ->currentText();
    QString  password =ui->password_lineEdit ->text();


    QSqlDatabase db;
    connect_to_database(db);
    QSqlQuery query(db);
   // QString 2="select clano,claname from class WHERE  claname='软件三班';";

    query.exec("select clano from class WHERE  clano='" + clano + "'");
    if(query.size() == 0)
    {
        QMessageBox::warning(this, "修改失败", "该班级号不存在！");
        return;
    }



 //password<-hash
   password = QCryptographicHash::hash(password.toLatin1(),QCryptographicHash::Md5).toHex();


//修改除了身份证之外的
QString sqlupdate1=QString("update student set sname = '%0', ssex = '%1',"
                     "sbirth = '%2', clano = '%3', sorigin = '%4', sstatus = '%5',"
                     "shome = '%6', szipcode = '%7' ,snote='%8',suserstatus='%9',spassword='%10',snote='%11'where sno = '%13'").arg(sname).arg(sex).arg(age).arg(clano).arg(sorigin)
                     .arg(sstatus).arg(shome).arg(szipcode).arg(snote).arg(status).arg(password).arg(snote).arg(sno);

bool isUpdateSuccess1 = query.exec(sqlupdate1);

qDebug()<<sqlupdate1<<endl;

//修改身份证
QString sqlupdate2=QString("UPDATE stu_sid set sid='%0'WHERE sno='%1'").arg(sid).arg(sno);
bool isUpdateSuccess2 = query.exec(sqlupdate2);

qDebug()<<sqlupdate2<<endl;

    if(isUpdateSuccess1&&isUpdateSuccess2)
    {
        //qDebug() << status;
        QMessageBox::information(this, "提示", "修改成功");
    }
    else {
        QMessageBox::warning(this, "提示", "修改失败！请检查输入信息是否有误！");
    }


}

void stuinfomanage::on_addStuInfo_button_clicked()
{
    addStuInfo *asi = new addStuInfo;
    this->hide();
    asi->show();
}



//这里害没改！！
void stuinfomanage::on_listAllStu_button_clicked()
{
    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);
query.exec("select sno,sname,ssex,sbirth,clano,sorigin,sstatus,sid,shome,szipcode,s_year,snote from stu_stu_sid_view ");
qDebug()<<query.exec("select sno,sname,ssex,sbirth,clano,sorigin,sstatus,sid,shome,szipcode,s_year,snote from stu_stu_sid_view ");
    while(query.next())
    {
        QStringList q;

        for(int i=0;i<=11;i++)
        qDebug()<<query.value(i).toString()<<endl;

        QString sno=query.value(0).toString();
        QString sname=query.value(1).toString();
        QString sex=query.value(2).toString();
        QString age=query.value(3).toString();
        QString clano=query.value(4).toString();
        QString sorigin=query.value(5).toString();
        QString sstatus=query.value(6).toString();
        QString sid=query.value(7).toString();
        QString shome=query.value(8).toString();
        QString szipcode=query.value(9).toString();
        QString syear=query.value(10).toString();
        QString snote=query.value(11).toString();


        q << sno << sname << sex << age <<clano<<sorigin<<sstatus<<sid<<shome<<szipcode<<syear<<snote;
        list_all_student.append(q);
    }
    this->hide();
    all_stu_info * all = new all_stu_info;
    all->show();
}

void stuinfomanage::on_delete_button_clicked()
{
    QMessageBox::StandardButton btn;
    btn = QMessageBox::question(this, "确认删除", "确定要删除此学生信息吗？", QMessageBox::Yes|QMessageBox::No);
    if(btn == QMessageBox::Yes)
    {
        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        QString sno = ui->sno_lineEdit->text();

        bool isDeleteSuccess = query.exec("delete from student where sno = '" + sno + "'");

        if(isDeleteSuccess)
        {
           QMessageBox::information(this, "提示", "删除成功");

           ui->sno_lineEdit          ->clear();
           ui->sname_lineEdit        ->clear();
           ui->sexBox                ->setCurrentIndex(0);
           ui->age_lineEdit          ->clear();
           ui->clano_lineEdit        ->clear();
           ui->sorigin_lineEdit      ->clear();
           ui->sstatus_lineEdit      ->clear();
           ui->sid_lineEdit          ->clear();
           ui->shome_lineEdit        ->clear();
           ui->szipcode              ->clear();
           ui->snote_lineEdit        ->clear();
           ui->statusBox             ->setCurrentIndex(0);
           ui->password_lineEdit     ->clear();

            ui->sno_lineEdit->setFocus();

            ui->update_button->setDisabled(true);
           ui->delete_button->setDisabled(true);
           ui->reset_button->setDisabled(true);

        }
        else {
            QMessageBox::warning(this, "提示", "删除失败");
        }
    }
}

void stuinfomanage::on_reset_button_clicked()
{
    QMessageBox::StandardButton btn;
    btn = QMessageBox::question(this, "确认重置", "确定要重置此学生密码吗？", QMessageBox::Yes|QMessageBox::No);
    if(btn == QMessageBox::Yes)
    {
        QString sno = ui->sno_lineEdit->text();
        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        QString originPwd = "123456";
        QString md5_pwd = QCryptographicHash::hash(originPwd.toLatin1(),QCryptographicHash::Md5).toHex();

        bool isResetPwdSuccess = query.exec("update student set spassword = '" + md5_pwd + "' where sno = '" + sno + "'");
        if(isResetPwdSuccess)
        {
            QMessageBox::information(this, "提示", "已将此学生密码重置为初始密码");
        }
        else {
            QMessageBox::warning(this, "警告", "重置失败！");
        }
    }
}
