#include "sqlback.h"
#include "global.h"
#include <QMessageBox>
#include <QDebug>
#include <qprocess.h>
sqlback::sqlback()

{
//    QString Cmd = QString("D:\\software_install\\mysql_in_win64\\mysql-8.0.28-winx64\\bin\\mysqldump.exe");
//    QStringList argument;
//    argument<<"--add-drop-table"<<"-u"<<sqlUser<<"-p"<<sqlPwd<<"student";
//    qDebug()<<argument<<endl;
//    QString Path = QString("%1").arg("d://backup.sql");
//    QProcess *poc=new QProcess;
//    poc->setStandardOutputFile(Path);
//    poc->start(Cmd,argument);
//    QMessageBox::information(0,"","备份完成！");



//    QString Path = QString("%1").arg("d://backup.Sql");
//    QString Cmd = QString("mysqldump.exe -u%1 -p%2 --default-character-set=gbk --opt --extended-insert=false --triggers -R --hex-blob -x pipme").arg("root").arg("123456");
//     QProcess *poc=new QProcess;
//        poc->setStandardOutputFile(Path);
//        poc->start(Cmd);
//        poc->waitForFinished();

    //mysql数据备份


//        QString Cmd = QString(" mysqldump -h%1 -P%2 -u %3 -p%4 %5").arg("127.0.0.1","3306","root","123456","student_manager");
//        //QString strPath = QString("%1").arg("c://aa//backup.Sql");
//        QString strPath="d://aa";
//        QProcess p(nullptr);
//        p.setStandardOutputFile(QString("%1//backup.sql").arg(strPath));
//        p.start(Cmd);
//        p.waitForStarted();
//        p.waitForFinished();
//        QMessageBox::information(0,"","备份完成！");

}

bool sqlback::backup()
{  QString Cmd = QString("D:\\software_install\\mysql_in_win64\\mysql-8.0.28-winx64\\bin\\mysqldump.exe --add-drop-table -u%1 -p%2 student_manager").arg(sqlUser,sqlPwd);
    QString Path = QString("%1").arg("d://backup.Sql");
    QProcess *poc=new QProcess;
    poc->setStandardOutputFile(Path);
    poc->start(Cmd);
    QMessageBox::information(0,"","备份完成！");

}

bool sqlback::reset()
{
    QString Cmd = QString("mysql.exe -u%1 -p%2 student_manager").arg(sqlUser,sqlPwd);
    QString Path = QString("%1").arg("d://backup.Sql");
    QProcess *poc=new QProcess;
    poc->setStandardInputFile(Path);
    poc->start(Cmd);
    QMessageBox::information(0,"","恢复完成！");

}
