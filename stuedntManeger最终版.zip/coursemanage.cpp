#include "coursemanage.h"
#include "ui_coursemanage.h"
#include "global.h"
#include "manager.h"
#include <QMessageBox>
#include "allcourseinfo.h"
#include "addnewcourse.h"

courseManage::courseManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::courseManage)
{
    ui->setupUi(this);
    ui->timeBox->addItem("大一上");
    ui->timeBox->addItem("大一下");
    ui->timeBox->addItem("大二上");
    ui->timeBox->addItem("大二下");
    ui->timeBox->addItem("大三上");
    ui->timeBox->addItem("大三下");
    ui->timeBox->addItem("大四上");
    ui->timeBox->addItem("大四下");
    ui->update_button->setDisabled(true);
    ui->delete_button->setDisabled(true);
}

courseManage::~courseManage()
{
    delete ui;
}

void courseManage::on_bakc_button_clicked()
{
    manager * m = new manager;
    this->hide();
    m->show();
}

void courseManage::on_searchButton_clicked()
{
    QString cno = ui->courseId_lineEdit->text();
    QSqlDatabase db;
    connect_to_database(db);

    QSqlQuery query(db);

    query.exec("select cname, cteacher, cterm, ccredit, cnote from course where cno = '" + cno + "'");
    if(query.next())
    {
        QString cname = query.value(0).toString();
        QString cteacher = query.value(1).toString();
        QString cterm = query.value(2).toString();
        QString ccredit = query.value(3).toString();
        QString cnote = query.value(4).toString();

        ui->courseName_lineEdit->setText(cname);
        ui->teacher_lineEdit->setText(cteacher);
        ui->timeBox->setCurrentIndex(ui->timeBox->findText(cterm));
        ui->credit_lineEdit->setText(ccredit);
        ui->cnote_lineEdit->setText(cnote);
        ui->update_button->setDisabled(false);
        ui->delete_button->setDisabled(false);
    }
    else {
        ui->update_button->setDisabled(true);
        ui->delete_button->setDisabled(true);

        ui->courseName_lineEdit->clear();
        ui->teacher_lineEdit->clear();
        ui->timeBox->setCurrentIndex(0);
        ui->credit_lineEdit->clear();

        QMessageBox::warning(this, "查询无果", "不存在该课程！");

        ui->courseId_lineEdit->setFocus();

    }
}

void courseManage::on_listAllCourse_button_clicked()
{
    this->hide();
    allCourseInfo *aci = new allCourseInfo;
    aci->show();
}

void courseManage::on_add_button_clicked()
{
    addNewCourse *anc = new addNewCourse;
    this->hide();
    anc->show();
}

void courseManage::on_update_button_clicked()
{
    QMessageBox::StandardButton btn;
    btn = QMessageBox::question(this, "确认修改", "确定修改此课程信息？", QMessageBox::Yes|QMessageBox::No);
    if(btn == QMessageBox::Yes)
    {
        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        QString cno= ui->courseId_lineEdit->text();
        QString cname = ui->courseName_lineEdit->text();
        QString cteacher = ui->teacher_lineEdit->text();
        QString cterm = ui->timeBox->currentText();
        QString ccredit = ui->credit_lineEdit->text();
        QString cnote = ui->cnote_lineEdit->text();

        bool isUpdateInCourseSuccess = query.exec(QString("update course "
            "set cname = '%0',cteacher = '%1', cterm='%2',ccredit='%3',cnote='%4' where cno = '%5'")
            .arg(cname).arg(cteacher).arg(cterm).arg(ccredit).arg(cnote).arg(cno));

        if( isUpdateInCourseSuccess)
        {
            QMessageBox::information(this, "提示", "修改成功");

        }
        else {
            QMessageBox::warning(this, "修改失败", "请检查输入信息！");
        }
    }

}

void courseManage::on_delete_button_clicked()
{
    QMessageBox::StandardButton btn;
    btn = QMessageBox::question(this, "确认删除", "确定删除此课程信息？", QMessageBox::Yes|QMessageBox::No);
    if(btn == QMessageBox::Yes)
    {
        QSqlDatabase db;
        connect_to_database(db);
        QSqlQuery query(db);

        QString cno = ui->courseId_lineEdit->text();

        bool isDeleteSuccess = query.exec("delete from course where cno = '" + cno + "'");

        if(isDeleteSuccess)
        {
            QMessageBox::information(this, "提示", "删除成功");
        }
        else {
            QMessageBox::warning(this, "警告", "删除失败！");
        }
    }
}
